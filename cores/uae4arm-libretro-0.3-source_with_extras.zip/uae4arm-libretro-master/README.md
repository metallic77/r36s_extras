# uae4arm-libretro

Based on old uae4arm version with psp support.

## Controls

|RetroPad button|Action|
|---|---|
|B|Fire button 1 / Red|
|A|Fire button 2 / Blue|
|L2|Left mouse button|
|R2|Right mouse button|
|L|Switch to previous disk|
|R|Switch to next disk|
|Select|Toggle virtual keyboard|
|Start|Toggle mouse emulation|

Right analog stick controls the mouse.

In mouse emulation mode dpad and fire button controls the mouse.

Two joysticks support. Switch automatically between mouse or second joystick when a mouse or 2nd joystick button is pressed.

L & R button can change DF0: current disk for multiple disk roms. Each disk should be named with "(Disk x of y)"

Automatic support of WHDload slave in .lha file. 

Kickstarts supported in options configuration:

|System|Version|Filename|Size|MD5|
|---|---|---|---|---|
|A500|KS v1.3 rev 34.005|**kick34005.A500**|262 144|82a21c1890cae844b3df741f2762d48d|
|A600|KS v3.1 rev 40.063|**kick40063.A600**|524 288|e40a5dfb3d017ba8779faba30cbd1c8e|
|A1200|KS v3.1 rev 40.068|**kick40068.A1200**|524 288|646773759326fbac3b2311fd8c8793ee|

If kickstart is not present, AROS kickstart replacement will be used.
## Extra core options (added)

- **Force 60Hz output** (`uae4arm_force60hz`): reports 60 fps to the frontend so a 60Hz screen can use vsync. Emulation speed is unchanged (a PAL game still runs at 50Hz: one frame in six is shown twice).
- **Mouse speed** (`uae4arm_mouse_speed`): 25% to 400%, applies to real mouse, d-pad mouse emulation and right analog stick.
- **Virtual keyboard transparency** (`uae4arm_vkbd_transparency`): 0% (opaque) to 90%. The keyboard has the same height at every internal resolution (320/640/768 wide).
- **Joypad X / Y / L3 / R3 button sends key**: assign an Amiga keyboard key (Space, Return, Esc, F1-F10, cursors, Shift, Ctrl, Alt, 0-9, A-Z ...) to those joypad buttons.
- **Joypad L / R button**: same list, plus `Default` (previous / next disk, the original behaviour). Picking a key or `None` disables the disk change on that button.

### Option categories and live changes

Core options are grouped in the RetroArch menu (core options v2; frontends without v2 get the same list as a flat menu):
**System** (Model, Fast Mem, Fast copper), **Video** (Internal resolution, Leds on screen, Force 60Hz), **Media** (Floppy speed), **Input** (Mouse speed, Virtual keyboard transparency, joypad button mapping).

Changing an option while a game runs no longer re-applies the whole machine setup (that added the WHDLoad/LHA drives again to the running emulator and crashed the core).
Live changes apply to: resolution, leds, floppy speed, fast copper, mouse speed, keyboard transparency, key mapping and Force 60Hz.
**Model** and **Fast Mem** are applied the next time the content is loaded.
