# uae4arm-libretro

Based on old uae4arm version with psp support.

## Controls

|RetroPad button|Action|
|---|---|
|B|Fire button 1 / Red|
|A|Fire button 2 / Blue|
|L2|Left mouse button|
|R2|Right mouse button|
|L|Switch to previous disk|
|R|Switch to next disk|
|Select|Toggle virtual keyboard|
|Start|Toggle mouse emulation|

Right analog stick controls the mouse.

In mouse emulation mode dpad and fire button controls the mouse.

Two joysticks support. Switch automatically between mouse or second joystick when a mouse or 2nd joystick button is pressed.

L & R button can change DF0: current disk for multiple disk roms. Each disk should be named with "(Disk x of y)"

Automatic support of WHDload slave in .lha file. 

Kickstarts supported in options configuration:

|System|Version|Filename|Size|MD5|
|---|---|---|---|---|
|A500|KS v1.3 rev 34.005|**kick34005.A500**|262 144|82a21c1890cae844b3df741f2762d48d|
|A600|KS v3.1 rev 40.063|**kick40063.A600**|524 288|e40a5dfb3d017ba8779faba30cbd1c8e|
|A1200|KS v3.1 rev 40.068|**kick40068.A1200**|524 288|646773759326fbac3b2311fd8c8793ee|

If kickstart is not present, AROS kickstart replacement will be used.
## Extra core options (added)

- **CPU speed** (`uae4arm_cpu_speed`, 50% to 300% in 10% steps, default 100%): speed of the emulated CPU relative to the selected model (100% = the model's original speed, e.g. 68000 at 7 MHz on an A500). The cycles of every instruction are scaled (`cpu_speed_mul` in `newcpu.cpp`), so 200% executes twice as many instructions per frame. Useful for games that run too slow (e.g. Monkey Island); lower it for games that run too fast. Changes apply live.
- **Force 60Hz output** (`uae4arm_force60hz`), for 60Hz screens:
  - `Repeat frames` (`on`): 60Hz output for vsync, game speed unchanged (PAL games stay at 50 real frames per second, one frame in six is shown twice).
  - `NTSC timing` (`ntsc`): the emulated Amiga runs at 60Hz (`ntscmode` + `chipset_refreshrate=60`, both are needed), so there are 60 real frames per second, but PAL games run about 20% faster.
- **Vertical centering** (`uae4arm_vcenter`, default `auto`): the picture is centred on the display window (DIWSTRT/DIWSTOP) of the running program. Before, the window always started at a fixed Amiga line (41 on PAL), so programs whose display starts higher lost their top lines while empty lines were left at the bottom. `off` restores the old behaviour.
- **PAL to NTSC aspect fix (vertical zoom)** (`uae4arm_aspect_fix`, off / 200 / 216 / 224 / 240 lines): for NTSC games running in a 256 line PAL screen (e.g. Monkey Island: 320x200 inside 320x256), which look too short. Shows only the middle N lines of the screen (the picture is centered there by *Vertical centering*); the frontend keeps 4:3, so those lines fill the screen height. Presentation only, it does not change the emulation. The full screen is shown while the virtual keyboard is open; the leds are cut when active.
- **Vertical offset (lines)** (`uae4arm_vertical_offset`, -24 to +24): fine tunes the vertical position, on top of the centering.
- **Mouse speed** (`uae4arm_mouse_speed`): 25% to 400%, applies to real mouse, d-pad mouse emulation and right analog stick.
- **Virtual keyboard transparency** (`uae4arm_vkbd_transparency`): 0% (opaque) to 90%. The keyboard has the same height at every internal resolution (320/640/768 wide).
- **Joypad X / Y / L3 / R3 button sends key**: assign an Amiga keyboard key (Space, Return, Esc, F1-F10, cursors, Shift, Ctrl, Alt, 0-9, A-Z ...) to those joypad buttons.
- **Joypad L / R button**: same list, plus `Default` (previous / next disk, the original behaviour). Picking a key or `None` disables the disk change on that button.

### Option categories and live changes

Core options are grouped in the RetroArch menu (core options v2; frontends without v2 get the same list as a flat menu):
**System** (Model, Fast Mem, CPU speed, Fast copper), **Video** (Internal resolution, Leds on screen, Vertical centering, Vertical offset, PAL to NTSC aspect fix, Force 60Hz), **Media** (Floppy speed), **Input** (Mouse speed, Virtual keyboard transparency, joypad button mapping).

Changing an option while a game runs no longer re-applies the whole machine setup (that added the WHDLoad/LHA drives again to the running emulator and crashed the core).
Live changes apply to: CPU speed, resolution, leds, floppy speed, fast copper, mouse speed, keyboard transparency, key mapping, Vertical centering/offset and Force 60Hz.
**Model** and **Fast Mem** are applied the next time the content is loaded.
